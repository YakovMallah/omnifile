A small project archive for the omnifile playground.
