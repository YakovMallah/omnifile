A small archive for the omnifile playground.
